import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './../employee.service';


@Component({
  selector: 'app-time',
  templateUrl: './time.component.html',
  styleUrls: ['./time.component.css']
})
export class TimeComponent implements OnInit {
  newcomponent = "Entered in new component created";
  todaydate;
  constructor(private myservice: EmployeeService) { }
  ngOnInit() {
    this.todaydate = this.myservice.showTodayDate();
  }
}