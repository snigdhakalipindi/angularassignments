import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  
    
    <h2 *ngIf="haserror ; else elseBlock " >
    true the directive will display if block.... 
    </h2>
    <ng-template   #elseBlock> 
    false the directive will  display else block 
    </ng-template>
    
  <div [ngSwitch]="color">
  <div *ngSwitchCase="'red'" > say red color </div>
  <div *ngSwitchCase="'pink'" > say pink color </div>
  <div *ngSwitchCase="'orange'" > say orange color </div>

  <div *ngFor="let pens of pens">
  <h2>{{pens}} </h2>
  </div>

    `,
  styles: [`    
   .text-success{
        color: green;
   }
  
  `]
})
export class TestComponent implements OnInit {
  public pens = ["natraj", "flair", "pinpoijnt"];
  public color = "pink";
  public abc = "";
  public name = "angular";
  public name1 = "started";
  public myId = "testID";
  public haserror = "true";
  public greeting = "";

  constructor() { }

  ngOnInit(): void {
  }
  greet() {
    return "Angular " + this.name1;

  }
  Onclick() {
    return this.greeting = "Welcome to page";
  }
  logmessage(value) {
    console.log(value);
  }
}