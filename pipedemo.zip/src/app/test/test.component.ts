import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: ` <h2> {{name}} </h2>
  <h2> {{name | lowercase}} </h2>
  <h2> {{name | uppercase}} </h2>
  <h2> {{name | lowercase}} </h2>
  <h2> {{message | titlecase}} </h2>
  <h2> {{name | slice:3:5}} </h2>
  <h2> {{name1 | json}} </h2>
  <h2> {{5.997 | number:'1.2-3'}} </h2>
  <h2> {{1.99997 | number:'3.5-6'}} </h2>
  <h2> {{0.97 | percent}} </h2>
  <h2> {{1.997 | currency}} </h2>
  <h2>{{10000|currency:'EURO'}}</h2>
  <h2>{{10000|currency:'INR'}}</h2>


  <h2>{{date}}</h2>
  <h2>{{date| date:'short'}}</h2>
  <h2>{{date| date:'shortDate'}}</h2>
  <h2>{{date| date:'shortTime'}}</h2>








 `,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  public name = "snigdha";
  public name1 = { "firstname": "snigdha", "lastname": "kalipindi" };

  public message = "welcome to angular";
  public date = new Date();
  constructor() { }

  ngOnInit(): void {
  }

}
